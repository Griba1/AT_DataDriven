import os
import json
import streamlit as st
from football_stats.competitions import get_competitions, get_matches
from football_stats.matches import get_lineups, get_events, get_player_stats
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import StreamlitChatMessageHistory
from langchain.schema import AIMessage, HumanMessage

from langchain_community.callbacks.streamlit import StreamlitCallbackHandler
from tools.football import get_sport_specialist_comments_about_match as comments_about_a_match
from tools import load_tools
from agent import load_agent

# Defina as credenciais do Google Cloud
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/caminho/para/o/arquivo/credenciais.json"

# Configuração da chave de API diretamente estou usando a minha propria quando for utilizar só trocar
os.environ["GOOGLE_API_KEY"] = "AIzaSyCjTongKSjx4NisJ8KwkHIPuUkXb8DI8qI"

# Streamlit configurações
st.set_page_config(layout="wide", page_title="Football Match Conversation App", page_icon="⚽️")

msgs = StreamlitChatMessageHistory()

if "memory" not in st.session_state:
    st.session_state["memory"] = ConversationBufferMemory(messages=msgs, memory_key="chat_history", return_messages=True)

memory = st.session_state.memory

def memorize_message():
    user_input = st.session_state["user_input"]
    st.session_state["memory"].chat_memory.add_message(HumanMessage(content=user_input))

def load_competitions():
    """
    Simula o carregamento de competições da sua função.
    Substitua isso pela chamada real para buscar competições.
    """
    return json.loads(get_competitions())

def load_matches(competition_id, season_id):
    """
    Simula o carregamento de partidas para uma competição específica.
    Substitua isso pela chamada real para buscar partidas de uma competição.
    """
    return json.loads(get_matches(competition_id, season_id))

def get_player_profile(match_id, player_name):
    """
    Função para obter o perfil do jogador com base no nome e ID da partida.
    """
    # Carregar as estatísticas do jogador
    player_stats = json.loads(get_player_stats(match_id, player_name))  # Passando player_name para a função
    return player_stats

# Sidebar do Streamlit
st.sidebar.title("Football Match Selector")
# Passo 1: Selecionar uma Competição
selected_competition = None
selected_season = None
selected_match = None
match_id = None
match_details = None
specialist_comments = None
selected_player = None

st.sidebar.header("Selecionar uma Competição")
competitions = load_competitions()
competition_names = sorted(set([comp['competition_name'] for comp in competitions]))
selected_competition = st.sidebar.selectbox("Escolha uma Competição", competition_names)
if selected_competition:
    # Passo 2: Selecionar uma Temporada
    st.sidebar.header("Selecionar uma Temporada:")
    seasons = set(comp['season_name'] for comp in competitions if comp['competition_name'] == selected_competition)
    selected_season = st.sidebar.selectbox("Escolha uma Temporada", sorted(seasons))
    
if selected_season:
    # Obter o ID da competição selecionada
    competition_id = next(
        (comp['competition_id'] for comp in competitions if comp['competition_name'] == selected_competition),
        None
    )
    season_id = next(
        (comp['season_id'] for comp in competitions if comp['season_name'] == selected_season and comp['competition_name'] == selected_competition),
        None
    )
    # Passo 2: Selecionar uma Partida
    st.sidebar.header("Selecionar uma Partida:")
    matches = load_matches(competition_id, season_id)
    match_names = sorted([f"{match['home_team']} vs {match['away_team']}" for match in matches])
    
    if selected_match := st.sidebar.selectbox("Escolha uma Partida", match_names):
        # Obter o ID da partida selecionada
        match_details = next(
            (match for match in matches if f"{match['home_team']} vs {match['away_team']}" == selected_match),
            None
        )
        match_id = match_details['match_id']

# Página Principal
if not match_id:
    st.title("Partidas Futebol")
    st.write("Use a barra lateral para selecionar uma competição, depois uma partida, e inicie uma conversa.")
else:
    st.markdown(
    """
    <style>
    .title {
        text-align: center;
    }
    </style>
    """,
    unsafe_allow_html=True)
    st.markdown(f'<h1 class="title">{selected_match}</h1><h3 class="title">{selected_competition} - Temporada {selected_season}</h3>', unsafe_allow_html=True)

    # Escolher o estilo de resposta
    st.sidebar.header("Escolha o Estilo de Resposta: ")
    response_style = st.sidebar.radio(
        "Como você gostaria que a IA respondesse?",
        ('Humorístico', 'Formal', 'Técnico')
    )

    # Passo 5: Buscar Perfil do Jogador
    st.sidebar.header("Buscar Perfil do Jogador:")
    st.write("Exemplo de jogadores : Hakan Çalhanoğlu, Jeffrey Gouweleeuw, Paul Verhaegh - Para identificar os jogadores é só ver os respectivos jogadores daquele time na epoca do ano")
    st.write("Exemplo de perguntas : Quem jogou melhor? - Pode ser testado nos perfils humoristicos, tecnico etc... Para o agente quem chutou mais no gol? ")
    selected_player = st.sidebar.text_input("Digite o nome do jogador para ver o perfil")

    if selected_player and match_id:
        # Buscar perfil do jogador
        try:
            player_profile = get_player_profile(match_id, selected_player)
            st.write("Perfil do Jogador:")
            st.json(player_profile)  # Exibe o perfil do jogador no formato JSON
        except Exception as e:
            st.error(f"Erro ao carregar perfil do jogador: {e}")

    with st.container(border=False):
        st.chat_input(key="user_input", on_submit=memorize_message)
        if user_input := st.session_state.user_input:
            chat_history = st.session_state["memory"].chat_memory.messages
            for msg in chat_history:
                if isinstance(msg, HumanMessage):
                    with st.chat_message("user"):
                        st.write(f"{msg.content}")
                elif isinstance(msg, AIMessage):
                    with st.chat_message("assistant"):
                        st.write(f"{msg.content}")

            with st.spinner("Agente está respondendo..."):
                try:
                    # Carregar o agente
                    agent = load_agent()

                    # Cache de ferramentas para evitar chamadas redundantes
                    tools = load_tools()
                    tool_names = [tool.name for tool in tools]
                    tool_descriptions = [tool.description for tool in tools]

                    # Preparar entrada para o agente
                    input_data = {
                        "match_id": match_id,
                        "match_name": selected_match,
                        "input": user_input,
                        "agent_scratchpad": "",
                        "competition_id": competition_id,
                        "season_id": season_id,
                        "tool_names": tool_names,
                        "tools": tool_descriptions,
                        "response_style": response_style  # Passa o estilo de resposta
                    }

                    # Invocar o agente
                    response = agent.invoke(input=input_data, handle_parsing_errors=True)

                    # Validar a resposta
                    if isinstance(response, dict) and "output" in response:
                        output = response.get("output")
                    else:
                        output = "Desculpe, não consegui entender seu pedido. Tente novamente."

                    # Adicionar resposta à memória de chat
                    st.session_state["memory"].chat_memory.add_message(AIMessage(content=output))

                    # Exibir resposta no chat
                    with st.chat_message("assistant"):
                        st.write(output)

                except Exception as e:
                    # Tratar e exibir erros de forma amigável
                    st.error(f"Erro durante a execução do agente: {str(e)}")
                    st.write("Certifique-se de que seus inputs e a configuração do agente estão corretos.")

from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Optional

# Criando a aplicação FastAPI
app = FastAPI()

# Definindo os modelos com Pydantic

# Modelo para dados de um jogador
class PlayerProfile(BaseModel):
    player_name: str
    team_name: str
    position: str
    goals: int
    assists: int
    yellow_cards: int
    red_cards: int
    minutes_played: int

# Modelo para dados de resumo de uma partida
class MatchSummary(BaseModel):
    match_id: int
    home_team: str
    away_team: str
    score_home: int
    score_away: int
    date: str
    goals_home: int
    goals_away: int
    top_scorer: Optional[str] = None
    player_of_the_match: Optional[str] = None
    match_stats: Optional[List[str]] = []

# Endpoint para retornar a sumarização de uma partida
@app.get("/match_summary", response_model=MatchSummary)
async def get_match_summary(match_id: int):
    # Simulando uma resposta para o resumo de uma partida
    if match_id == 1:
        return MatchSummary(
            match_id=1,
            home_team="Augsburg",
            away_team="Bayer Leverkusen",
            score_home=2,
            score_away=1,
            date="2015-08-21",
            goals_home=2,
            goals_away=1,
            top_scorer="Hakan Çalhanoğlu",
            player_of_the_match="Hakan Çalhanoğlu",
            match_stats=["Possession: 60%-40%", "Shots: 15-10", "Corners: 5-3"]
        )
    else:
        return MatchSummary(
            match_id=match_id,
            home_team="Unknown",
            away_team="Unknown",
            score_home=0,
            score_away=0,
            date="Unknown",
            goals_home=0,
            goals_away=0
        )

# Endpoint para retornar o perfil detalhado de um jogador
@app.get("/player_profile", response_model=PlayerProfile)
async def get_player_profile(player_name: str, team_name: str):
    # Simulando uma resposta para o perfil de um jogador
    if player_name.lower() == "hakan çalhanoğlu" and team_name.lower() == "bayer leverkusen":
        return PlayerProfile(
            player_name="Hakan Çalhanoğlu",
            team_name="Bayer Leverkusen",
            position="Midfielder",
            goals=10,
            assists=8,
            yellow_cards=3,
            red_cards=0,
            minutes_played=2450
        )
    elif player_name.lower() == "jeffrey gouweleeuw" and team_name.lower() == "augsburg":
        return PlayerProfile(
            player_name="Jeffrey Gouweleeuw",
            team_name="Augsburg",
            position="Defender",
            goals=3,
            assists=1,
            yellow_cards=5,
            red_cards=0,
            minutes_played=2200
        )
    else:
        return PlayerProfile(
            player_name=player_name,
            team_name=team_name,
            position="Unknown",
            goals=0,
            assists=0,
            yellow_cards=0,
            red_cards=0,
            minutes_played=0
        )

# Rodando o servidor
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
